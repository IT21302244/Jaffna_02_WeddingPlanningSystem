// Wedding_Planning_System.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>

#include<cstring>
using namespace std;

int main()
{
    
}
#pragma once
#include<iostream>
#include<cstring>
using namespace std;
class Admin
{
private:
	char aName[50];
	int aId;
	string aEmail;
	int aContactNo;
	string aLocation;
public:
	Admin();
	Admin(char Name[], int ID, string Email, int Contact, string Location);
	void assign_aDetails();
	void dispaly_aDetails();

};


Admin::Admin()
{
}

Admin::Admin(char Name[], int ID, string Email, int Contact, string Location)
{
	strcpy_s(aName, Name);
	aId = ID;
	aEmail = Email;
	aContactNo = Contact;
	aLocation = Location;
}

void Admin::assign_aDetails()
{
}

void Admin::dispaly_aDetails()
{
}


class Payment
{
private:
	int prId;
	int pId;
	char pType[30];
	float pAmount;
public:
	Payment();
	Payment(int CustomerID, int ID, char Type[], float Amount);
	void assign_pDetails();
	void display_pDetails();
};

Payment::Payment()
{
}
Payment::Payment(int CustomerID, int ID, char Type[], float Amount)
{
	prId = CustomerID;
	pId = ID;
	strcpy_s(pType, Type);
	pAmount = Amount;
}

void Payment::assign_pDetails()
{
}

void Payment::display_pDetails()
{
}

class RegisteredCustomer
{
private:
	char rName[50];
	int rId;
	string rLocation;
	string rEmail;
	int rAge;
	string rDoB;
	char rGender[15];
	int rContact;
	string rUserName;
public:
	RegisteredCustomer();
	RegisteredCustomer(char Name[], int ID, string Location, string Email, int Age, string DoB, char Gender[], int Contact, string UserName);
	void assign_rDetails();
	void display_rDetails();

};

RegisteredCustomer::RegisteredCustomer()
{
}
RegisteredCustomer::RegisteredCustomer(char Name[], int ID, string Location, string Email, int Age, string DoB, char Gender[], int Contact, string UserName)
{
	strcpy_s(rName, Name);
	rId = ID;
	rLocation = Location;
	rEmail = Email;
	rAge = Age;
	rDoB = DoB;
	strcpy_s(rGender, Gender);
	rContact = Contact;
	rUserName = UserName;

}

void RegisteredCustomer::assign_rDetails()
{
}

void RegisteredCustomer::display_rDetails()
{
}
// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
